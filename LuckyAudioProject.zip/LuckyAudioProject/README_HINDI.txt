LUCKY AUDIO - Android app source project

Is project mein:
1. Audio recording (microphone permission ke saath)
2. Apni recording list se play karna
3. Live monitor: mic ki awaaz earphones/headphones par sunne ki koshish

Zaroori baat:
- Yeh Android Studio source project hai, seedha install hone wala APK nahi.
- APK banane ke liye Android Studio wala computer ya Android build environment chahiye.
- Is chat se main aapke phone par app install nahi kar sakta.
- Call recording shamil nahi hai, kyunki Android/phone restrictions aur privacy rules ke kaaran yeh har phone par kaam nahi karti.
- Live monitor ke liye headphones use karein; speaker se feedback/tez awaaz ho sakti hai.
