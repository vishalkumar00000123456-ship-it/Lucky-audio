package com.luckyaudio.app;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.AudioTrack;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQ_MIC = 100;
    private TextView status, listTitle;
    private LinearLayout recordingsBox;
    private MediaRecorder recorder;
    private MediaPlayer player;
    private File currentFile;
    private volatile boolean monitoring = false;
    private AudioRecord audioRecord;
    private AudioTrack audioTrack;
    private Thread monitorThread;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
        refreshRecordings();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(28, 28, 28, 28);
        root.setBackgroundColor(0xFFF6F8FB);
        scroll.addView(root);

        TextView title = new TextView(this);
        title.setText("Lucky Audio");
        title.setTextSize(30);
        title.setTextColor(0xFF123B67);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 16, 0, 8);
        root.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("Voice Recorder • Live Mic Monitor");
        subtitle.setTextSize(14);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setPadding(0, 0, 0, 20);
        root.addView(subtitle);

        status = new TextView(this);
        status.setText("Ready — microphone permission is needed.");
        status.setTextSize(15);
        status.setPadding(12, 12, 12, 18);
        root.addView(status);

        addButton(root, "🎙  Start Recording", v -> startRecording());
        addButton(root, "■  Stop Recording", v -> stopRecording());
        addButton(root, "🔊  Start Live Mic Monitor", v -> startMonitor());
        addButton(root, "■  Stop Live Monitor", v -> stopMonitor());
        addButton(root, "↻  Refresh Recordings", v -> refreshRecordings());

        listTitle = new TextView(this);
        listTitle.setText("Saved recordings");
        listTitle.setTextSize(20);
        listTitle.setTextColor(0xFF123B67);
        listTitle.setPadding(0, 22, 0, 8);
        root.addView(listTitle);

        recordingsBox = new LinearLayout(this);
        recordingsBox.setOrientation(LinearLayout.VERTICAL);
        root.addView(recordingsBox);

        TextView privacy = new TextView(this);
        privacy.setText("\nPrivacy: Recording starts only when you tap Start Recording. Use the mic lawfully and respect other people's privacy. Live monitor works best with headphones.");
        privacy.setTextSize(13);
        privacy.setPadding(0, 20, 0, 20);
        root.addView(privacy);

        setContentView(scroll);
    }

    private void addButton(LinearLayout parent, String label, View.OnClickListener listener) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(16);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 6, 0, 6);
        parent.addView(b, lp);
        b.setOnClickListener(listener);
    }

    private boolean hasMicPermission() {
        if (Build.VERSION.SDK_INT >= 23 &&
                checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
            status.setText("Please allow microphone permission, then tap the button again.");
            return false;
        }
        return true;
    }

    private File getRecordingDir() {
        File dir = new File(getExternalFilesDir(Environment.DIRECTORY_MUSIC), "LuckyAudio");
        if (!dir.exists()) dir.mkdirs();
        return dir;
    }

    private void startRecording() {
        if (!hasMicPermission()) return;
        if (recorder != null) { toast("Recording already running"); return; }
        try {
            String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
            currentFile = new File(getRecordingDir(), "LuckyAudio_" + stamp + ".m4a");
            if (Build.VERSION.SDK_INT >= 31) {
                recorder = new MediaRecorder(this);
            } else {
                recorder = new MediaRecorder();
            }
            recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
            recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
            recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
            recorder.setAudioSamplingRate(44100);
            recorder.setAudioEncodingBitRate(128000);
            recorder.setOutputFile(currentFile.getAbsolutePath());
            recorder.prepare();
            recorder.start();
            status.setText("Recording: " + currentFile.getName());
            toast("Recording started");
        } catch (Exception e) {
            releaseRecorder();
            status.setText("Could not start recording: " + e.getMessage());
            toast("Recording could not start");
        }
    }

    private void stopRecording() {
        if (recorder == null) { toast("No recording is running"); return; }
        try {
            recorder.stop();
            status.setText("Saved: " + (currentFile != null ? currentFile.getName() : "recording"));
            toast("Recording saved");
        } catch (Exception e) {
            status.setText("Recording was too short or could not be saved.");
        } finally {
            releaseRecorder();
            refreshRecordings();
        }
    }

    private void releaseRecorder() {
        if (recorder != null) {
            try { recorder.reset(); } catch (Exception ignored) {}
            try { recorder.release(); } catch (Exception ignored) {}
            recorder = null;
        }
    }

    private void startMonitor() {
        if (!hasMicPermission()) return;
        if (monitoring) { toast("Live monitor already running"); return; }
        try {
            final int sampleRate = 16000;
            final int min = AudioRecord.getMinBufferSize(sampleRate,
                    AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
            if (min <= 0) { toast("Microphone monitor not supported on this device"); return; }
            final int buffer = Math.max(min, 4096);
            audioRecord = new AudioRecord(MediaRecorder.AudioSource.MIC, sampleRate,
                    AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, buffer);
            audioTrack = new AudioTrack(android.media.AudioManager.STREAM_MUSIC, sampleRate,
                    AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT,
                    buffer, AudioTrack.MODE_STREAM);
            if (audioRecord.getState() != AudioRecord.STATE_INITIALIZED ||
                    audioTrack.getState() != AudioTrack.STATE_INITIALIZED) {
                stopMonitor();
                toast("Audio monitor unavailable on this device");
                return;
            }
            monitoring = true;
            audioRecord.startRecording();
            audioTrack.play();
            monitorThread = new Thread(() -> {
                short[] data = new short[buffer / 2];
                while (monitoring) {
                    int n = audioRecord.read(data, 0, data.length);
                    if (n > 0 && monitoring) audioTrack.write(data, 0, n);
                }
            }, "LuckyAudioMonitor");
            monitorThread.start();
            status.setText("Live microphone monitor is ON. Use headphones.");
            toast("Live monitor started");
        } catch (Exception e) {
            stopMonitor();
            status.setText("Live monitor failed: " + e.getMessage());
        }
    }

    private void stopMonitor() {
        monitoring = false;
        try { if (audioRecord != null) audioRecord.stop(); } catch (Exception ignored) {}
        try { if (audioTrack != null) audioTrack.pause(); } catch (Exception ignored) {}
        try { if (audioTrack != null) audioTrack.flush(); } catch (Exception ignored) {}
        try { if (audioRecord != null) audioRecord.release(); } catch (Exception ignored) {}
        try { if (audioTrack != null) audioTrack.release(); } catch (Exception ignored) {}
        audioRecord = null;
        audioTrack = null;
        monitorThread = null;
        status.setText("Live monitor stopped.");
    }

    private void refreshRecordings() {
        if (recordingsBox == null) return;
        recordingsBox.removeAllViews();
        File[] files = getRecordingDir().listFiles((dir, name) -> name.endsWith(".m4a"));
        if (files == null || files.length == 0) {
            TextView empty = new TextView(this);
            empty.setText("No recordings yet.");
            recordingsBox.addView(empty);
            return;
        }
        java.util.Arrays.sort(files, (a, b) -> Long.compare(b.lastModified(), a.lastModified()));
        for (File f : files) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.VERTICAL);
            row.setPadding(12, 10, 12, 10);
            row.setBackgroundColor(0xFFFFFFFF);
            TextView name = new TextView(this);
            name.setText(f.getName());
            name.setTextSize(14);
            row.addView(name);
            LinearLayout buttons = new LinearLayout(this);
            buttons.setOrientation(LinearLayout.HORIZONTAL);
            Button play = new Button(this);
            play.setText("▶ Play");
            play.setAllCaps(false);
            Button delete = new Button(this);
            delete.setText("Delete");
            delete.setAllCaps(false);
            buttons.addView(play, new LinearLayout.LayoutParams(0, -2, 1));
            buttons.addView(delete, new LinearLayout.LayoutParams(0, -2, 1));
            row.addView(buttons);
            recordingsBox.addView(row);
            play.setOnClickListener(v -> playFile(f));
            delete.setOnClickListener(v -> {
                if (player != null) { try { player.stop(); } catch (Exception ignored) {} try { player.release(); } catch (Exception ignored) {} player = null; }
                if (f.delete()) toast("Recording deleted");
                else toast("Could not delete recording");
                refreshRecordings();
            });
        }
    }

    private void playFile(File f) {
        try {
            if (player != null) { try { player.stop(); } catch (Exception ignored) {} player.release(); }
            player = new MediaPlayer();
            player.setDataSource(f.getAbsolutePath());
            player.setOnCompletionListener(mp -> { mp.release(); if (player == mp) player = null; });
            player.prepare();
            player.start();
            status.setText("Playing: " + f.getName());
        } catch (Exception e) {
            toast("Could not play this recording");
        }
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_MIC) {
            status.setText(grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED
                    ? "Microphone allowed. Tap the feature you want."
                    : "Microphone permission denied.");
        }
    }

    @Override protected void onStop() {
        super.onStop();
        if (monitoring) stopMonitor();
        if (recorder != null) stopRecording();
    }

    @Override protected void onDestroy() {
        stopMonitor();
        if (player != null) { try { player.release(); } catch (Exception ignored) {} player = null; }
        releaseRecorder();
        super.onDestroy();
    }
}
